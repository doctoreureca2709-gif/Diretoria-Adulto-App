# Diretoria Adulto — versão 2

Aplicação Android 18+, sem anúncios comerciais.

Inclui confirmação de idade, pesquisa, filtros, favoritos, diretório e links para recursos externos legais. Não aloja nem distribui vídeos explícitos.

Substituir os exemplos por conteúdos/links para os quais exista autorização e que sejam legais.
