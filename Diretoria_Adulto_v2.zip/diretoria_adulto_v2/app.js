const listings = [
  {id:1,name:"Espaço Lisboa 18+",city:"Lisboa",category:"Eventos 18+",desc:"Diretório de eventos e espaços destinados a público adulto.",url:"https://example.com"},
  {id:2,name:"Diretório Porto",city:"Porto",category:"Comunidades",desc:"Recursos e comunidades para adultos, apresentados de forma responsável.",url:"https://example.com"},
  {id:3,name:"Braga Adult",city:"Braga",category:"Entretenimento",desc:"Seleção de recursos de entretenimento para maiores de 18 anos.",url:"https://example.com"},
  {id:4,name:"Faro Noite",city:"Faro",category:"Eventos 18+",desc:"Agenda e referências de atividades noturnas para adultos.",url:"https://example.com"},
  {id:5,name:"Coimbra Bem-Estar",city:"Coimbra",category:"Bem-estar",desc:"Recursos relacionados com bem-estar e autocuidado adulto.",url:"https://example.com"},
  {id:6,name:"Recursos 18+",city:"Évora",category:"Recursos 18+",desc:"Links externos para recursos legais destinados a adultos.",url:"https://example.com"}
];

let favorites = JSON.parse(localStorage.getItem("da_favorites") || "[]");
let view = "home";

const $ = id => document.getElementById(id);
const ageGate = $("ageGate");

if (localStorage.getItem("da_age_ok") === "1") ageGate.classList.add("hidden");

$("enterBtn").onclick = () => {
  localStorage.setItem("da_age_ok","1");
  ageGate.classList.add("hidden");
};

function renderChips(){
  const cats = [...new Set(listings.map(x=>x.category))];
  $("chips").innerHTML = cats.map(c=>`<button class="chip" data-cat="${c}">${c}</button>`).join("");
  document.querySelectorAll(".chip").forEach(b=>b.onclick=()=>{ $("category").value=b.dataset.cat; render(); });
}

function filtered(){
  const q = $("search").value.trim().toLowerCase();
  const city = $("city").value;
  const cat = $("category").value;
  let a = listings.filter(x =>
    (!q || (x.name+" "+x.city+" "+x.category+" "+x.desc).toLowerCase().includes(q)) &&
    (!city || x.city===city) &&
    (!cat || x.category===cat)
  );
  if(view==="favorites") a = a.filter(x=>favorites.includes(x.id));
  return a;
}

function card(x){
  const fav = favorites.includes(x.id);
  return `<article class="card">
    <div class="cardTop"><span class="tag">${x.category}</span><button class="fav" data-id="${x.id}">${fav?"♥":"♡"}</button></div>
    <h3>${x.name}</h3>
    <div class="city">${x.city}</div>
    <p>${x.desc}</p>
    <div class="actions">
      <button class="details" data-id="${x.id}">Ver detalhes</button>
      <a href="${x.url}" target="_blank" rel="noopener">Abrir recurso</a>
    </div>
  </article>`;
}

function render(){
  const a = filtered();
  $("sectionTitle").textContent = view==="favorites" ? "Os meus favoritos" : view==="about" ? "Sobre" : "Diretório";
  if(view==="about"){
    $("cards").innerHTML = `<article class="card about">
      <h3>Diretoria Adulto</h3>
      <p>Aplicação privada de diretório 18+, sem anúncios comerciais.</p>
      <p>Os conteúdos e recursos externos devem ser legais, destinados a adultos e respeitar os direitos das pessoas e dos respetivos autores.</p>
      <p class="small">Esta versão não aloja nem distribui vídeos explícitos.</p>
    </article>`;
    $("count").textContent="";
    $("empty").classList.add("hidden");
    return;
  }
  $("count").textContent = `${a.length} resultado${a.length===1?"":"s"}`;
  $("cards").innerHTML = a.map(card).join("");
  $("empty").classList.toggle("hidden", a.length>0);

  document.querySelectorAll(".fav").forEach(b=>b.onclick=()=>{
    const id=Number(b.dataset.id);
    favorites=favorites.includes(id)?favorites.filter(v=>v!==id):[...favorites,id];
    localStorage.setItem("da_favorites",JSON.stringify(favorites)); render();
  });
  document.querySelectorAll(".details").forEach(b=>b.onclick=()=>{
    const x=listings.find(v=>v.id===Number(b.dataset.id));
    $("modalContent").innerHTML=`<span class="tag">${x.category}</span><h2>${x.name}</h2><p>${x.city}</p><p>${x.desc}</p><a class="primary" href="${x.url}" target="_blank" rel="noopener">Abrir recurso externo</a>`;
    $("modal").classList.remove("hidden");
  });
}
$("closeModal").onclick=()=> $("modal").classList.add("hidden");
$("modal").onclick=e=>{if(e.target=== $("modal")) $("modal").classList.add("hidden")};
$("search").oninput=render; $("city").onchange=render; $("category").onchange=render;
document.querySelectorAll(".navBtn").forEach(b=>b.onclick=()=>{view=b.dataset.view; document.querySelectorAll(".navBtn").forEach(x=>x.classList.remove("active")); b.classList.add("active"); render();});
$("favTop").onclick=()=>{view="favorites"; render();};
renderChips(); render();
