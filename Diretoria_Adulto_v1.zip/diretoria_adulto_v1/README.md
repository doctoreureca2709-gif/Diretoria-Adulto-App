# Diretoria Adulto
Base inicial da aplicação Android/web.

Inclui barreira 18+, pesquisa, filtros, favoritos e detalhes.
Os dados são demonstrativos e devem ser substituídos por conteúdo legal e autorizado.
