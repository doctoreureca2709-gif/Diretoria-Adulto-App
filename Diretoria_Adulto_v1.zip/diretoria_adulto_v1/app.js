const listings=[
 {id:1,name:"Espaço Lisboa 18+",city:"Lisboa",category:"Entretenimento",desc:"Espaço de entretenimento para adultos, com informação e contactos apresentados pelo anunciante."},
 {id:2,name:"Diretório Porto",city:"Porto",category:"Eventos",desc:"Agenda e diretório de eventos destinados a maiores de 18 anos."},
 {id:3,name:"Braga Adult",city:"Braga",category:"Serviços",desc:"Página de apresentação de serviços legais para adultos."},
 {id:4,name:"Faro Noite",city:"Faro",category:"Entretenimento",desc:"Informação sobre opções de entretenimento para adultos."}
];
let favorites=JSON.parse(localStorage.getItem("da_favorites")||"[]");
const $=id=>document.getElementById(id);
function render(view="home"){
 const q=$("search").value.toLowerCase().trim(), city=$("city").value, cat=$("category").value;
 let data=listings.filter(x=>(!q||(x.name+" "+x.city+" "+x.category).toLowerCase().includes(q))&&(!city||x.city===city)&&(!cat||x.category===cat));
 if(view==="favorites") data=data.filter(x=>favorites.includes(x.id));
 $("count").textContent=data.length+" resultado"+(data.length===1?"":"s");
 $("cards").innerHTML=data.length?data.map(x=>`<article class="card"><div class="avatar">18+</div><div class="card-body"><div class="title">${x.name}</div><div class="meta">${x.city} · ${x.category}</div><span class="tag">Maiores de 18</span></div><div class="card-actions"><button class="heart" onclick="toggleFav(${x.id})">${favorites.includes(x.id)?"♥":"♡"}</button><button class="details" onclick="openDetails(${x.id})">Ver</button></div></article>`).join(""):`<div class="empty">Não foram encontrados resultados.</div>`;
}
function toggleFav(id){favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];localStorage.setItem("da_favorites",JSON.stringify(favorites));render(document.querySelector(".nav.active").dataset.view)}
function openDetails(id){const x=listings.find(a=>a.id===id);$("modalContent").innerHTML=`<h2>${x.name}</h2><p class="meta">${x.city} · ${x.category}</p><p>${x.desc}</p><p class="meta">Demonstração — os conteúdos reais devem ser adicionados pelo proprietário da aplicação e cumprir a legislação aplicável.</p>`;$("modal").classList.remove("hidden")}
$("enterBtn").onclick=()=>{$("ageGate").classList.add("hidden");localStorage.setItem("da_age_ok","1")}
if(localStorage.getItem("da_age_ok")==="1")$("ageGate").classList.add("hidden");
["search","city","category"].forEach(id=>$(id).addEventListener("input",()=>render()));
$("closeModal").onclick=()=>$("modal").classList.add("hidden");
$("modal").onclick=e=>{if(e.target.id==="modal")$("modal").classList.add("hidden")};
document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>{document.querySelectorAll(".nav").forEach(n=>n.classList.remove("active"));b.classList.add("active");render(b.dataset.view)});
$("favTop").onclick=()=>document.querySelector('[data-view="favorites"]').click();
render();
